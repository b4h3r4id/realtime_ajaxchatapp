    <!--<p align="right"><label class="mode-control">
        <input id="mode-btn" type="checkbox" class="mod-span">
        <span><img src="css/images/light-mod.jpg" alt=""></span>
        <span><img src="css/images/night-mod.jpg" alt=""></span>
    </label></p>
    <script src="javascript/nightmod.js"></script>-->
<!--Coded b4h3r4id-->
    <p align ="right"><label class="mode-control">
        <input id="mode-btn" type="checkbox" class="mod-span">
        <span><i class="fas fa-adjust"></i></span>
        <span><i class="fa fa-adjust"></i></span>
    </label></p>
    <script src="javascript/darkmode.js"></script>

